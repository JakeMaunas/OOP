import java.io.*;
import java.util.Scanner;

public class Admin_Account {

    private String username, Password;
    private File Admin = new File("FILES/Admin.txt");

    Admin_Account(){
        try {
            Scanner scan = new Scanner(new FileReader(Admin));
                try {
                    username = scan.next();
                    scan.skip(" - ");
                    Password = scan.next();
                }catch (Exception err) {}
            scan.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public String get_username(){
        return username;
    }

    public String get_password(){
        return Password;
    }
}
