import java.util.*;
import java.util.spi.AbstractResourceBundleProvider;

public class input {
    Scanner s = new Scanner(System.in);
    Loan_CRUD LoanCRUD = new Loan_CRUD();
    Record LoanRecord = new Record();

    input(){
        while (true){
            System.out.println("=========== LENDING SYSTEM ===========\n");
            System.out.println("[1] Login\n[2] Exit program");
            System.out.print("Enter Choice: ");

            int choice = 0;
            try{
                choice = Integer.parseInt(s.nextLine());
            }catch (Exception e){
                System.out.println("\nEnter Numbers Only\n");
                continue;
            }

            if (choice == 1){
                if(login()){
                    while (true){
                        System.out.println("=========== LENDING SYSTEM / TASK ===========\n");
                        System.out.println("[1] Add Loan\n[2] Pay Loan\n[3] Show Balance\n[4] Exit");
                        System.out.print("Enter Choice: ");

                        int choice2 = 0;
                        try{
                            choice2 = Integer.parseInt(s.nextLine());
                        }catch (Exception e){
                            System.out.println("\nEnter Numbers Only\n");
                            continue;
                        }

                        switch (choice2){
                            case 1:
                                add_loan();
                                break;
                            case 2:
                                pay_loan();
                                break;
                            case 3:
                                showBalance();
                                break;
                            case 4:
                                return;
                            default:
                                System.out.println("\nChoose only 1-4\n");
                        }
                    }
                }
            }

            else if (choice == 2){
                break;
            }
            else{
                System.out.println("\nChoose only 1/2\n");
            }
        }
    }

    public boolean login(){
        System.out.println("=========== LOG-IN ===========\n");
        Admin_Account admin = new Admin_Account();
        String username = "", password = "";
        try{
            System.out.print("Enter Username: ");
            username = s.nextLine();
            System.out.print("Enter Password: ");
            password = s.nextLine();
        }catch (Exception e){
            System.out.println("\nMust Fill The Information\n");
            return false;
        }

        if (admin.get_username().equals(username) && admin.get_password().equals(password)){
            return true;
        }else{
            System.out.println("\nIncorrect username/password\n");
            return false;
        }
    }

    public void add_loan(){
        System.out.println("=========== ADD LOAN ===========\n");
        Loan_Accounts account = new Loan_Accounts();
        try{
            System.out.print("Enter Loan ID: ");
            account.setId(Integer.parseInt(s.nextLine()));

            System.out.print("\nEnter Name: ");
            account.setName(s.nextLine());

            System.out.print("\nEnter Address: ");
            account.setAddress(s.nextLine());

            System.out.print("\nEnter Number: ");
            account.setNumber(s.nextLine());

            System.out.print("\nEnter Amount of Loan: ");
            account.setLoan(Double.parseDouble(s.nextLine()));

            System.out.print("\nEnter Term(Month/s): ");
            account.setTerm(Integer.parseInt(s.nextLine()));

            System.out.print("\nEnter Rate(Interest of Loan): %");
            account.setRate(Double.parseDouble(s.nextLine())/100);
        }catch (Exception e){
            System.out.println("\nMust Fill The Information\n");
            return;
        }

        LoanCRUD.create_loanAccount(account);
    }

    public void pay_loan(){
        System.out.println("=========== PAY LOAN ===========\n");
        System.out.print("Enter Account ID: ");
        int id = 0;
        try {
            id = Integer.parseInt(s.nextLine());
        }catch (NumberFormatException e){
            System.out.println("\nINVALID INPUT");
        }

        if(LoanCRUD.idaccountConfirmation(id)){
            if(LoanCRUD.CheckBalance(id)){
                Loan_Accounts account = LoanCRUD.getloanaccount(id);
                Records record = new Records();

                System.out.printf("Ammount to pay this month: %.2f", account.getLoanThisMonth());
                System.out.print("\nEnter Ammount to Pay: ");
                record.setPay(Double.parseDouble(s.nextLine()));
                account.setPay(record.getPay());

                int term = (int) (record.getPay()/account.getLoanPerMonth());

                if(term > 1){
                    record.setTerm(account.getTermPayed()+1);
                    account.setTermPayed(record.getTerm());
                    LoanRecord.create_record(record, account);
                    record.setPay(0);
                    for(int i = 0; i < term-1; i++){
                        record.setTerm(account.getTermPayed()+1);
                        account.setTermPayed(record.getTerm());
                        LoanRecord.create_record(record, account);
                    }
                }else{
                    record.setTerm(account.getTermPayed()+1);
                    account.setTermPayed(record.getTerm());
                    LoanRecord.create_record(record, account);
                }

                LoanCRUD.UpdateLoanAccount(account);
            }else{
                System.out.println("\nYou Already Payed Your Loan");
            }
        }else{
            System.out.println("\nAccount Does Not Exist");
        }
    }

    public void showBalance(){
        System.out.println("=========== SHOW BALANCE ===========\n");

        System.out.print("Enter Account ID: ");
        int id = 0;
        try {
            id = Integer.parseInt(s.nextLine());
        }catch (NumberFormatException e){
            System.out.println("\nINVALID INPUT");
        }

        if (LoanCRUD.idaccountConfirmation(id)){
            Loan_Accounts account = LoanCRUD.getloanaccount(id);

            System.out.println("==================================================\n");
            System.out.println("Account ID:\t\t" + account.getId());
            System.out.println("Name:\t\t\t" + account.getName());
            System.out.println("Address:\t\t" + account.getAddress());
            System.out.println("Number:\t\t\t" + account.getNumber());

            System.out.println("\nMoney Loaned:\t\t" + account.getLoan());
            System.out.println("Term(Month/s):\t\t" + account.getTerm());
            System.out.println("Rate(Interest):\t\t" + account.getRate()*100 + "%");

            System.out.printf("\nTotal Loaned:\t\t%.2f", account.getTotalLoan());
            System.out.println("\nTotal TermPayed:\t" + account.getTermPayed());
            System.out.printf("Total Payed:\t\t%.2f", account.getPay());

            System.out.println("\n____________________________________________________");
            System.out.printf("Remaining Balance:\t%.2f", account.getRemainingBalance());
            System.out.println("\n==================================================\n");
        }else{
            System.out.println("\nAccount Does Not Exist");
        }
    }
}
