import javax.swing.*;
import java.io.*;
import java.util.*;

public class Loan_CRUD {
    File Loan_Account;

    Loan_CRUD(){
        Loan_Account = new File("FILES/LoanAccounts.txt");
    }

    public List<Loan_Accounts> getAllLoanAccounts(){
        ArrayList<Loan_Accounts> loan_ACCLIST = new ArrayList<>();
        try {
            Scanner scan = new Scanner(new FileReader(Loan_Account));
            while (scan.hasNextLine()){
                try {
                    Loan_Accounts acc = new Loan_Accounts();
                    acc.setId(Integer.parseInt(scan.next()));

                    scan.skip(" / ");
                    acc.setName(scan.next());

                    scan.skip(" / ");
                    acc.setAddress(scan.next());

                    scan.skip(" / ");
                    acc.setNumber(scan.next());

                    scan.skip(" / ");
                    acc.setLoan(Double.parseDouble(scan.next()));

                    scan.skip(" / ");
                    acc.setTerm(Integer.parseInt(scan.next()));

                    scan.skip(" / ");
                    acc.setRate(Double.parseDouble(scan.next()));

                    scan.skip(" / ");
                    acc.setTermPayed(Integer.parseInt(scan.next()));

                    scan.skip(" / ");
                    acc.setPay(Double.parseDouble(scan.next()));

                    loan_ACCLIST.add(acc);
                }catch (Exception e){}
            }
            scan.close();
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }
        return loan_ACCLIST;
    }

    public void create_loanAccount(Loan_Accounts account){
        boolean flag = true;
        List<Loan_Accounts> loan_ACCLIST = getAllLoanAccounts();
        for (Loan_Accounts record : loan_ACCLIST) {
            try {
                if (record.getId() == account.getId()) {
                    throw new ErrorHandler("Duplicate ID Error");
                }
            } catch (ErrorHandler err) {
                flag = false;
                System.out.println(err.getMessage());
            }
        }

        if (flag) {
            FileWriter fw;
            BufferedWriter bw;
            try {
                fw = new FileWriter(Loan_Account, true);
                bw = new BufferedWriter(fw);

                bw.write(account.WriteToFile());
                bw.write("\n");
                bw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public Loan_Accounts getloanaccount(int id){
        List<Loan_Accounts> loanAccountsList = getAllLoanAccounts();
        for(Loan_Accounts account : loanAccountsList){
            if (account.getId() == id){
                return account;
            }
        }
        return null;
    }

    public boolean idaccountConfirmation(int id) {
        List<Loan_Accounts> loanAccountsList = getAllLoanAccounts();
        for (Loan_Accounts use : loanAccountsList) {
            if (use.getId() == id) {
                return true;
            }
        }
        return false;
    }

    public void UpdateLoanAccount(Loan_Accounts account){
        List<Loan_Accounts> accountsList = getAllLoanAccounts();

        for(Loan_Accounts list : accountsList){
            if(list.getId() == account.getId()){
                accountsList.set(accountsList.indexOf(list), account);
            }
        }

        String format = "";
        for (Loan_Accounts acc : accountsList) {
            format += acc.WriteToFile() + "\n";
        }
        try {
            Formatter formatFile = new Formatter(Loan_Account);
            formatFile.format("%S", format);
            formatFile.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public boolean CheckBalance(int id){
        List<Loan_Accounts> accountsList = getAllLoanAccounts();
        for(Loan_Accounts list : accountsList){
            if(list.getId() == id){
                if(list.getTotalLoan() <= list.getPay()){
                    return false;
                }
            }
        }
        return true;
    }
}

class ErrorHandler extends Exception {

    public ErrorHandler(String mess) {
        super(mess);
    }
}
