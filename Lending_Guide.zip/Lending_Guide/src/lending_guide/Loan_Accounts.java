public class Loan_Accounts {
    private String name, address, number;
    private int id, term, termPayed;
    private double rate, loan, pay;

    public void setLoan(double loan) { this.loan = loan; }

    public void setId(int id) { this.id = id; }

    public void setName(String name) { this.name = name.replace(" ", "_"); }

    public void setAddress(String address) { this.address = address.replace(" ", "_"); }

    public void setNumber(String number) { this.number = number; }

    public void setPay(double pay) { this.pay += pay; }

    public void setRate(double rate) { this.rate = rate; }

    public void setTerm(int term) { this.term = term; }

    public void setTermPayed(int termPayed) { this.termPayed = termPayed; }

    public double getLoan() { return loan; }

    public int getId() { return id; }

    public double getRate() { return rate; }

    public String getNumber() { return number; }

    public int getTerm() { return term; }

    public double getPay() { return pay; }

    public int getTermPayed() {
        return termPayed;
    }

    public double getLoanPerMonth(){
        double LPM = ((loan*rate)+loan)/term;
        return LPM;
    }

    public double getLoanThisMonth(){
        double LTM = pay-(getLoanPerMonth()*termPayed);
        if (LTM < 0){
            LTM = Math.abs(LTM) + getLoanPerMonth();
            return LTM;
        }else{
         LTM = getLoanPerMonth() - Math.abs(LTM);
         return LTM;
        }
    }

    public double getTotalLoan(){
        double total = (loan*rate)+loan;
        return total;
    }

    public double getRemainingBalance(){
        double total = getTotalLoan() - getPay();
        return total;
    }

    public String getName() { return name.replace("_", " "); }

    public String getAddress() { return address.replace("_", " "); }

    public String WriteToFile(){
        String format = id + " / " + name + " / " + address + " / " + number + " / " +
                        loan + " / " + term + " / " + rate + " / " + termPayed + " / " +
                        pay;
        return format;
    }
}
