public class Records {
    private double pay;
    private int id, term;
    private String name;

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name){
        this.name = name.replace(" ", "_");
    }

    public void setTerm(int term){
        this.term = term;
    }

    public void setPay(double pay){
        this.pay = pay;
    }

    public int getId() {
        return id;
    }

    public String getName(){
        return name.replace("_", " ");
    }

    public int getTerm(){
        return term;
    }

    public double getPay(){
        return pay;
    }

    public String WriteToFile(){
        String format = id +" / "+ name +" / "+ term +" / "+ pay;
        return format;
    }
}
