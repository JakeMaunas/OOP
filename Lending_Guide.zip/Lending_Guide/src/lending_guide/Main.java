public class Main {
    public static void main(String[] args) {
        input in = new input();
    }
}