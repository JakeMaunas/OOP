import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Record {
    File Loan_Record;
    Record(){
        Loan_Record = new File("FILES/Records.txt");
    }

    public List<Records> getAllLoanRecord(){
        ArrayList<Records> record_LIST = new ArrayList<>();
        try {
            Scanner scan = new Scanner(new FileReader(Loan_Record));
            while (scan.hasNextLine()){
                try{
                    Records rec = new Records();
                    rec.setId(Integer.parseInt(scan.next()));
                    scan.skip(" / ");
                    rec.setName(scan.next());
                    scan.skip(" / ");
                    rec.setTerm(Integer.parseInt(scan.next()));
                    scan.skip(" / ");
                    rec.setPay(Double.parseDouble(scan.next()));
                    record_LIST.add(rec);
                }catch (Exception er){}
            }
            scan.close();
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }
        return record_LIST;
    }

    public void create_record(Records record, Loan_Accounts account){

        record.setId(account.getId());
        record.setName(account.getName());

        FileWriter fw;
        BufferedWriter bw;
        try {
            fw = new FileWriter(Loan_Record, true);
            bw = new BufferedWriter(fw);

            bw.write(record.WriteToFile());
            bw.write("\n");
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Records getRecord(int id){
        List<Records> recordsList = getAllLoanRecord();
        for(Records record : recordsList){
            if (record.getId() == id){
                return record;
            }
        }
        return null;
    }
}
