import java.io.*;
import java.util.*;
public class SystemLoanAccount {
    File loanAccounts;
    SystemLoanAccount(){
        if (loanAccounts == null){
            loanAccounts = new File("FILES/LoanAccounts.txt");
        }
    }

    public List<LoanAccount> getAllLoanAccounts(){
        ArrayList<LoanAccount> loan_ACCLIST = new ArrayList<>();
        try {
            Scanner scan = new Scanner(new FileReader(loanAccounts));
            while (scan.hasNextLine()){
                try {
                    LoanAccount acc = new LoanAccount();
                    acc.setId(Integer.parseInt(scan.next()));

                    scan.skip(" / ");
                    acc.setName(scan.next());

                    scan.skip(" / ");
                    acc.setAddress(scan.next());

                    scan.skip(" / ");
                    acc.setNumber(scan.next());

                    scan.skip(" / ");
                    acc.setLoan(Double.parseDouble(scan.next()));

                    scan.skip(" / ");
                    acc.setTerm(Integer.parseInt(scan.next()));

                    scan.skip(" / ");
                    acc.setRate(Double.parseDouble(scan.next()));

                    scan.skip(" / ");
                    acc.setTermPayed(Integer.parseInt(scan.next()));

                    scan.skip(" / ");
                    acc.setPay(Double.parseDouble(scan.next()));

                    loan_ACCLIST.add(acc);
                }catch (Exception e){}
            }
            scan.close();
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }
        return loan_ACCLIST;
    }

    public void createLoanAccount(LoanAccount account){
        boolean flag = true;
        List<LoanAccount> loanAccountList = getAllLoanAccounts();
        for (LoanAccount record : loanAccountList) {
            try {
                if (record.getId() == account.getId()) {
                    throw new ErrorHandler("Duplicate ID Error");
                }
            } catch (ErrorHandler err) {
                flag = false;
                System.out.println(err.getMessage());
            }
        }

        if (flag) {
            FileWriter fw;
            BufferedWriter bw;
            try {
                fw = new FileWriter(loanAccounts, true);
                bw = new BufferedWriter(fw);

                bw.write(account.WriteToFile());
                bw.write("\n");
                bw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean idAccountConfirmation(int id) {
        List<LoanAccount> loanAccountsList = getAllLoanAccounts();
        for (LoanAccount accountloan : loanAccountsList) {
            if (accountloan.getId() == id) {
                return true;
            }
        }
        return false;
    }

    public LoanAccount getLoanAccount(int id){
        List<LoanAccount> loanAccountsList = getAllLoanAccounts();
        for(LoanAccount account : loanAccountsList){
            if (account.getId() == id){
                return account;
            }
        }
        return null;
    }

    public boolean checkBalance(int id){
        List<LoanAccount> accountsList = getAllLoanAccounts();
        for(LoanAccount account : accountsList){
            if(account.getId() == id){
                if(account.getTotalLoan() > account.getPay()){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean confirmTransaction(int id, double pay){
        List<LoanAccount> accountLoanList = getAllLoanAccounts();
        for(LoanAccount account : accountLoanList){
            if(account.getId() == id){
                if (account.getTerm() == account.getTermPayed()+1){
                    if(pay == Double.parseDouble(String.format("%.2f", account.getLoanThisMonth()))){
                        return true;
                    }else{
                        return false;
                    }
                }
                else if(pay >= Double.parseDouble(String.format("%.2f", account.getLoanThisMonth()))*0.75 &&
                        pay <= Double.parseDouble(String.format("%.2f", account.getLoanThisMonth()))){
                    return true;
                }
            }
        }
        return false;
    }

    public void updateLoanAccount(LoanAccount account){
        List<LoanAccount> loanAccountList = getAllLoanAccounts();

        for(LoanAccount loanAccount : loanAccountList){
            if(loanAccount.getId() == account.getId()){
                loanAccountList.set(loanAccountList.indexOf(loanAccount), account);
            }
        }

        String format = "";
        for (LoanAccount acc : loanAccountList) {
            format += acc.WriteToFile() + "\n";
        }
        try {
            Formatter formatFile = new Formatter(loanAccounts);
            formatFile.format("%S", format);
            formatFile.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
