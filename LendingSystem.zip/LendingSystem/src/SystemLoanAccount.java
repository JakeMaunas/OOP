public class SystemLoanAccount {
    File loanAccounts;
    SystemLoanAccount(){
        //mantua and bongo
    }

    public  getAllLoanAccounts(){
        //sayson and arabejo
    }

    public void createLoanAccount(){
        //mantua, bongo, Ramos, Badjao
    }

    public boolean idAccountConfirmation() {
        //Mantua and Bongo
    }

    public getLoanAccount(){
        //mantua and bongo
    }

    public boolean checkBalance(){
        //sayson and arabejo
    }

    public boolean confirmTransaction(){
        //sayson and arabejo
    }

    public void updateLoanAccount(){
        //sayson and arabejo
    }
}
