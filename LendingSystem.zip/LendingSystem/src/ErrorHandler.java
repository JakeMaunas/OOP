public class ErrorHandler extends Exception{
    //Badjao & Ramos
}
