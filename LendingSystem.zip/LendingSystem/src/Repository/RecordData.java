package Repository;

import Entity.Record;
import java.io.*;
import java.util.*;

public class RecordData {
    private final static File Records = new File("Files/Records.txt");

    public static List<Record> getLoanRecords(){
        ArrayList<Record> record_LIST = new ArrayList<>();
        try {
            Scanner scan = new Scanner(new FileReader(Records));
            while (scan.hasNextLine()){
                try{
                    Record rec = new Record();
                    rec.setId(Integer.parseInt(scan.next()));
                    scan.skip(" / ");
                    rec.setTerm(Integer.parseInt(scan.next()));
                    scan.skip(" / ");
                    rec.setBalance(Double.parseDouble(scan.next()));
                    scan.skip(" / ");
                    rec.setPay(Double.parseDouble(scan.next()));
                    record_LIST.add(rec);
                }catch (Exception ignored){}
            }
            scan.close();
        }catch (FileNotFoundException ignored){ }
        return record_LIST;
    }

    public static File getFile(){
        return Records;
    }
}
