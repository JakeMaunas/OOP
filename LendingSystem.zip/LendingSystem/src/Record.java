public class Record {
    private double pay;
    private int id, term;
    private String name;

    
    //set method - ramos and badjao
    //get mthod - mantua and bongo
    
    public void setId() {
    }

    public void setName(){
    }

    public void setTerm(){  }

    public void setPay(){
    }

    public int getId() {
    }

    public String getName(){
    }

    public int getTerm(){
    }

    public double getPay(){
    }

    public WriteToFile(){
        //sayson and arabejo
    }
}
