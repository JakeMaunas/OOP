import java.io.*;
import java.util.Scanner;

public class AdminAccount {
    private String username, Password;
    private File Admin;

    AdminAccount(){
        // Bongo & Mantua
    }

    public String get_username(){
        // Bongo & Mantua
    }

    public String get_password(){
        // Bongo & Mantua
    }
}
