public class LoanAccount {
    private String name, address, number;
    private int id, term, termPayed;
    private double rate, loan, pay;

    //set method - ramos and badjao
    //get mthod - mantua and bongo
    public void setLoan() { }

    public void setId() {  }

    public void setName() {  }

    public void setAddress() {}

    public void setNumber() { }

    public void setPay() {  }

    public void setRate() { }

    public void setTerm() { }

    public void setTermPayed() { }

    public double getLoan() {  }

    public int getId() {  }

    public double getRate() { }

    public String getNumber() { }

    public int getTerm() {  }

    public String getName() {  }

    public String getAddress() {}

    public double getPay() { }

    public int getTermPayed() {
    }

    public double getLoanPerMonth(){
    }

    public double getLoanThisMonth(){
        //sayson and arabejo
    }

    public double getTotalLoan(){
        //sayson and arabejo
    }

    public double getRemainingBalance(){
        //sayson and arabejo
    }

    public WriteToFile(){
        //sayson and arabejo
    }
}
