import java.text.DecimalFormat;
import java.text.NumberFormat;

public class LoanAccount {
    private String name, address, number;
    private int id, term, termPayed;
    private double rate, loan, pay;

    public void setLoan(double loan) { this.loan = loan; }

    public void setId(int id) { this.id = id; }

    public void setName(String name) { this.name = name.replace(" ", "_"); }

    public void setAddress(String address) { this.address = address.replace(" ", "_"); }

    public void setNumber(String number) { this.number = number; }

    public void setPay(double pay) { this.pay += pay; }

    public void setRate(double rate) { this.rate = rate; }

    public void setTerm(int term) { this.term = term; }

    public void setTermPayed(int termPayed) { this.termPayed = termPayed; }

    public double getLoan() { return loan; }

    public int getId() { return id; }

    public double getRate() { return rate; }

    public String getNumber() { return number; }

    public int getTerm() { return term; }

    public String getName() { return name.replace("_", " "); }

    public String getAddress() { return address.replace("_", " "); }

    public double getPay() { return pay; }

    public int getTermPayed() {
        return termPayed;
    }

    public double getLoanPerMonth(){
        double loanPerMonth = ((loan*rate)+loan)/term;
        return loanPerMonth;
    }

    public double getLoanThisMonth(){
        double loanThisMonth = pay-(getLoanPerMonth()*termPayed);
        if (loanThisMonth < 0){
            loanThisMonth = Math.abs(loanThisMonth) + getLoanPerMonth();
            return loanThisMonth;
        }else{
            loanThisMonth = getLoanPerMonth() - Math.abs(loanThisMonth);
            return loanThisMonth;
        }
    }

    public double getLoanInSpecificMonth(int term, Double pay){
        double loanThisMonth = pay-(getLoanPerMonth()*term);
        if (loanThisMonth < 0){
            loanThisMonth = Math.abs(loanThisMonth) + getLoanPerMonth();
            return loanThisMonth;
        }else{
            loanThisMonth = getLoanPerMonth() - Math.abs(loanThisMonth);
            return loanThisMonth;
        }
    }

    public double getTotalLoan(){
        double total = (loan*rate)+loan;
        return total;
    }

    public double getRemainingBalance(){
        double total = getTotalLoan() - getPay();
        return total;
    }

    public String WriteToFile(){
        String format = id + " / " + name + " / " + address + " / " + number + " / " +
                String.format("%.2f", loan) + " / " + term + " / " + rate + " / " + termPayed + " / " +
                String.format("%.2f", pay);
        return format;
    }
}
