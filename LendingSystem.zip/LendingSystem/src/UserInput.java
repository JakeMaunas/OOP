
public class UserInput {
    //By Group
}
