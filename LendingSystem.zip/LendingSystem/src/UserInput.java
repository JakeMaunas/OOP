import java.util.*;
public class UserInput {
    SystemLoanAccount systemAccount;
    SystemRecord systemRecord;

    Scanner s = new Scanner(System.in);
    int choice = 0;

    UserInput(){
        systemAccount = new SystemLoanAccount();
        systemRecord = new SystemRecord();

        while (true){
            System.out.println("==================== Lending System ====================\n");

            System.out.print("[1]Login\n[2]Exit\nEnter Choice: ");
            try{ choice = Integer.parseInt(s.nextLine()); }catch (Exception e){
                System.out.println("\nEnter Numbers Only\n");
                continue; }

            if(choice == 1){
                if(AdminLogin()){

                    while (true){
                        System.out.println("\n======================== System ========================\n");
                        System.out.println("[1] Add Loan\n[2] Pay Loan\n[3] Show Balance\n[4] Exit");
                        System.out.print("Enter Choice: ");

                        try{ choice = Integer.parseInt(s.nextLine()); }catch (Exception e){
                            System.out.println("\nEnter Numbers Only\n");
                            continue; }

                        switch (choice){
                            case 1:
                                addLoanAccount();
                                break;
                            case 2:
                                payLoanAccount();
                                break;
                            case 3:
                                showBalance();
                                break;
                            case 4:
                                return;
                            default:
                                System.out.println("\nChoose between 1-4\n");
                        }
                    }

                }else{
                    System.out.println("\nIncorrect username/password\n");
                }
            }
            else if(choice == 2){
                break;
            }else {
                System.out.println("\nChoose between 1-2\n");
            }
        }
    }

    public boolean AdminLogin(){
        AdminAccount account = new AdminAccount();
        System.out.println("\n===================== Login Account ====================\n");

        System.out.print("Enter Username: ");
        String userName = s.nextLine();
        System.out.print("Enter Password: ");
        String passWord = s.nextLine();

        return account.get_username().equals(userName) && account.get_password().equals(passWord) ? true : false;
    }

    public void addLoanAccount(){
        LoanAccount account = new LoanAccount();
        System.out.println("\n=================== Add Loan Account ===================\n");
        try{
            System.out.print("Enter Loan ID: ");
            account.setId(Integer.parseInt(s.nextLine()));

            System.out.print("\nEnter Name: ");
            account.setName(s.nextLine());

            System.out.print("\nEnter Address: ");
            account.setAddress(s.nextLine());

            System.out.print("\nEnter Number: ");
            account.setNumber(s.nextLine());

            System.out.print("\nEnter Amount of Loan: ");
            account.setLoan(Double.parseDouble(s.nextLine()));

            System.out.print("\nEnter Term(Month/s): ");
            account.setTerm(Integer.parseInt(s.nextLine()));

            System.out.print("\nEnter Rate(Interest of Loan): %");
            account.setRate(Double.parseDouble(s.nextLine())/100);
        }catch (Exception e){
            System.out.println("\nMust Fill The Information\n");
            return;
        }

        systemAccount.createLoanAccount(account);
    }

    public void payLoanAccount(){
        System.out.println("\n====================== Pay Loan ======================\n");
        System.out.print("Enter Account ID: ");
        int id = 0;
        try {
            id = Integer.parseInt(s.nextLine());
        }catch (NumberFormatException e){
            System.out.println("\nInvalid Input\n");
        }

        if(systemAccount.idAccountConfirmation(id)){
            if(systemAccount.checkBalance(id)){
                LoanAccount account = systemAccount.getLoanAccount(id);
                Record record = new Record();

                System.out.println("Month #" + (account.getTermPayed()+1) + ": " + String.format("%.2f", account.getLoanThisMonth()));
                if(account.getTerm() == account.getTermPayed()+1){
                    System.out.println("You must pay the exact ammount of this month.\n");
                }else{
                    System.out.println("You need to pay between " + String.format("%.2f", Double.parseDouble(String.format("%.2f", account.getLoanThisMonth()))*0.75) +
                            " - " + String.format("%.2f", account.getLoanThisMonth()) + "\n");
                }

                System.out.print("Enter Ammount to Pay: ");
                double pay = Double.parseDouble(s.nextLine());

                if(systemAccount.confirmTransaction(id, pay)){
                    record.setPay(pay);
                    account.setPay(pay);
                    record.setTerm(account.getTermPayed()+1);
                    account.setTermPayed(record.getTerm());
                    systemRecord.createRecord(record, account);
                    systemAccount.updateLoanAccount(account);
                }else{
                    System.out.println("\nTransaction Request Denied\n");
                }
            }else{
                System.out.println("\nYou Already Payed Your Loan\n");
            }
        }else{
            System.out.println("\nAccount Does Not Exist\n");
        }
    }

    public void showBalance(){
        System.out.println("=============== Loan Account Information ===============\n");

        System.out.print("Enter Account ID: ");
        int id = 0;
        try {
            id = Integer.parseInt(s.nextLine());
        }catch (NumberFormatException e){
            System.out.println("\nInvalid Input\n");
        }

        if (systemAccount.idAccountConfirmation(id)){
            LoanAccount account = systemAccount.getLoanAccount(id);

            System.out.println("========================================================\n");
            //personal
            System.out.println("Account ID:          " + account.getId());
            System.out.println("Name:                " + account.getName());
            System.out.println("Address:             " + account.getAddress());
            System.out.println("Number:              " + account.getNumber());

            //loan details
            System.out.println("\nMoney Loaned:        " + String.format("%.2f", account.getLoan()));
            System.out.println("Term(Month/s):       " + account.getTerm());
            System.out.println("Rate(Interest):      " + account.getRate()*100 + "%");

            //loan details
            System.out.println("\nTotal Loaned:        " + String.format("%.2f", account.getTotalLoan()));
            System.out.println("Total TermPayed:     " + account.getTermPayed());
            System.out.println("Total Payed:         " + String.format("%.2f", account.getPay()));

            //loan month details
            System.out.println("\n________________________________________________________\n");
            System.out.println("                Balance                Paid             ");
            double pay = 0;
            for(int i = 0; i < account.getTerm(); i++){
                Record record1 = systemRecord.getRecord(account.getId(), i+1);
                Record record2 = systemRecord.getRecord(account.getId(), i);

                if(record1 != null){
                    pay += record1.getPay();
                    if(record1.getPay() == Double.parseDouble(String.format("%.2f", account.getLoanInSpecificMonth(record1.getTerm(), pay)))){
                        System.out.println("Month #" + (i+1) + ":       " + String.format("%.2f", account.getLoanInSpecificMonth(record1.getTerm(), pay)) +
                                "                " + String.format("%.2f", record1.getPay()));
                    }else{
                        System.out.println("Month #" + (i+1) + ":       " + String.format("%.2f", (account.getLoanInSpecificMonth(i, pay) + record1.getPay())) +
                                "                " + String.format("%.2f", record1.getPay()));
                    }
                }else{
                    if(record2 != null){
                        System.out.println("Month #" + (i+1) + ":       " + String.format("%.2f", account.getLoanInSpecificMonth(record2.getTerm(), pay)) +
                                "                ");
                    }else{
                        System.out.println("Month #" + (i+1) + ":       " + String.format("%.2f", account.getLoanPerMonth()) +
                                "                ");
                    }
                }
            }

            System.out.println("________________________________________________________");
            System.out.println("Remaining Balance:   " + String.format("%.2f", account.getRemainingBalance()));
        }else{
            System.out.println("\nAccount Does Not Exist\n");
        }
    }
}
