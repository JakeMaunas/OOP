package Entity;
public class LoanAccount {
    private String name, address, number;
    private int id, term, termPayed, principalPayed = 1;
    private double interest, principal, loan, pay;

    //set methods
    public void setName(String name){ this.name = name.replace(" ", "_"); }
    public void setAddress(String address){ this.address = address.replace(" ", "_"); }
    public void setNumber(String number){ this.number = number; }

    public void setId(int id){ this.id = id; }
    public void setTerm(int term){ this.term = term; }
    public void setTermPayed(int termPayed){ this.termPayed = termPayed; }
    public void setPrincipalPayed(int principalPayed){ this.principalPayed = principalPayed; }

    public void setInterest(double interest){ this.interest = interest; }
    public void setLoan(double loan){ this.loan = loan; }

    public void setPay(double pay){ this.pay += pay; }
    public void setPrincipal(double principal){ this.principal += principal; }

    //get methods
    public String getName(){ return name.replace("_"," "); }
    public String getAddress(){ return address.replace("_", " "); }
    public String getNumber(){ return number; }

    public int getId(){ return id; }
    public int getTerm(){ return term; }
    public int getTermPayed(){ return termPayed; }
    public boolean getPrincipalPayed(){ return principalPayed == 1; }

    public double getInterest(){ return interest; }
    public double getLoan(){ return loan; }

    public double getPay(){ return pay; }
    public double getPrincipal() { return principal; }

    //Methods / Basic Calculation
    public double getPrincipalPerMonth(){ return (getTotalPrincipal()/term); }
    public double getRatePerMonth(){ return (loan*interest)/term; }
    public double getLoanPerMonth(){ return (getPrincipalPerMonth() + getRatePerMonth()); }

    public double getTotalPrincipal(){ return (loan - principal); }
    public double getTotalLoaned(){ return (loan*interest)+loan; }
    public double getTotalInterestRate(){ return loan*interest; }
    public double getRemainingBalance(){ return (getTotalLoaned() - getPay()) - getPrincipal(); }

    //Methods / MindBreaking Calculation
    public double getLoanThisMonth(){
        double loanThisMonth = pay-(getLoanPerMonth()*termPayed);
        if (loanThisMonth < 0){
            loanThisMonth = Math.abs(loanThisMonth) + getLoanPerMonth();
        }else {
            loanThisMonth = getLoanPerMonth() - Math.abs(loanThisMonth);
        }
        return Double.parseDouble(String.format("%.2f", loanThisMonth));
    }

    //file format
    public String getFileFormat(){
        return id + " / " + name + " / " + address + " / " +
                number + " / " + term + " / " + termPayed + " / " + principalPayed + " / " +
                String.format("%.4f", interest) + " / " + String.format("%.2f", loan) +
                " / " + String.format("%.2f", principal) + " / " + String.format("%.2f", pay);
    }
}
