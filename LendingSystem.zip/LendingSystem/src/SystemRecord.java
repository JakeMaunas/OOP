public class SystemRecord {
    File loanRecords;
    SystemRecord(){
        //Mantua and Bongo
    }

    public List<> getAllLoanRecord(){
        //sayson and arabejo
    }

    public void createRecord(){
        //matua, bongo, ramos and badjao
    }

    public getRecord(){
        //sayson and arabejo
    }
}
