import java.io.*;
import java.util.*;
public class SystemRecord {
    File loanRecords;
    SystemRecord(){
        if (loanRecords == null){
            loanRecords = new File("FILES/Records.txt");
        }
    }

    public List<Record> getAllLoanRecord(){
        ArrayList<Record> record_LIST = new ArrayList<>();
        try {
            Scanner scan = new Scanner(new FileReader(loanRecords));
            while (scan.hasNextLine()){
                try{
                    Record rec = new Record();
                    rec.setId(Integer.parseInt(scan.next()));
                    scan.skip(" / ");
                    rec.setName(scan.next());
                    scan.skip(" / ");
                    rec.setTerm(Integer.parseInt(scan.next()));
                    scan.skip(" / ");
                    rec.setPay(Double.parseDouble(scan.next()));
                    record_LIST.add(rec);
                }catch (Exception er){}
            }
            scan.close();
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }
        return record_LIST;
    }

    public void createRecord(Record record, LoanAccount account){

        record.setId(account.getId());
        record.setName(account.getName());

        FileWriter fw;
        BufferedWriter bw;
        try {
            fw = new FileWriter(loanRecords, true);
            bw = new BufferedWriter(fw);

            bw.write(record.WriteToFile());
            bw.write("\n");
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Record getRecord(int id, int term){
        List<Record> recordsList = getAllLoanRecord();
        for(Record record : recordsList){
            if (record.getId() == id && record.getTerm() == term){
                return record;
            }
        }
        return null;
    }
}
