package Crud;

import java.io.IOException;
import java.util.*;
import Repository.AdminData;
import Entity.LoanAccount;
import Entity.AdminAccount;
import Entity.Record;

public class UserInput {
    SystemLoanAccount systemAccount = new SystemLoanAccount();
    SystemRecord systemRecord = new SystemRecord();
    AdminAccount adminAccount = AdminData.getAdminAccount();

    Scanner s = new Scanner(System.in);
    int choice;

    public UserInput() {
        Screen1();
    }

    private void Screen1() {
        while (true) {
            System.out.println("================= Lending System ================");
            System.out.println("[1]Login\n[2]Exit");
            System.out.print("\nEnter Choice: ");
            try {
                choice = Integer.parseInt(s.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("\nInvalid input\n");
            }

            switch (choice) {
                case 1 -> Screen2();
                case 2 -> System.exit(0);
                default -> System.out.println(choice + " is not an Option\n");
            }
        }
    }

    private boolean Login() {
        System.out.println("\n===================== Login =====================");
        System.out.print("Enter Username: ");
        String username = s.nextLine();
        System.out.print("Enter Password: ");
        String password = s.nextLine();
        return adminAccount.getUsername().equals(username) && adminAccount.getPassword().equals(password);
    }

    private void Screen2() {
        if (Login()) {
            while (true) {
                System.out.println("\n================= Lending System ================");
                choice = 0;
                System.out.println("[1]Add Loan\n[2]Pay Loan\n[3]Show AccountLoan Details\n[4]Exit");
                System.out.print("\nEnter Choice: ");
                try {
                    choice = Integer.parseInt(s.nextLine());
                } catch (NumberFormatException e) {
                    System.out.println("\nInvalid input\n");
                }
                switch (choice) {
                    case 1 -> AddLoanAccount();
                    case 2 -> PayLoan();
                    case 3 -> ShowLoanAccountDetails();
                    case 4 -> System.exit(0);
                    default -> System.out.println(choice + " is not an Option");
                }
            }
        } else {
            System.out.println("\nIncorrect username/password\n");
        }
    }

    private void AddLoanAccount() {
        System.out.println("\n================ Add LoanAccount ================\n");
        LoanAccount account = new LoanAccount();

        try {
            System.out.print("Enter Loan ID: ");
            account.setId(Integer.parseInt(s.nextLine()));

            System.out.print("\nEnter Name: ");
            account.setName(s.nextLine());
            System.out.print("Enter Address: ");
            account.setAddress(s.nextLine());
            System.out.print("Enter Number: ");
            account.setNumber(s.nextLine());

            System.out.println("\n______________ Interest Ratings _________________");
            System.out.println("1              -    100               =  100.0%");
            System.out.println("101            -    500               =  75.0%");
            System.out.println("501            -    1,000             =  50.0%");
            System.out.println("1,000          -    10,000            =  18.0%");
            System.out.println("10,001         -    25,000            =  16.5%");
            System.out.println("25,001         -    50,000            =  14.5%");
            System.out.println("50,001         -    75,000            =  12.5%");
            System.out.println("75,001         -    100,000           =  10.5%");
            System.out.println("100,001        -    250,000           =   8.5%");
            System.out.println("250,001        -    500,000           =   7.0%");
            System.out.println("500,001        -    750,000           =   6.0%");
            System.out.println("750,001        -    1,000,000         =   5.0%");
            System.out.println("1,000,001      -    2,500,000         =   4.0%");
            System.out.println("2,500,001      -    5,000,000         =   3.0%");
            System.out.println("5,000,001      -    10,000,000        =   2.5%");
            System.out.println("_________________________________________________\n");

            System.out.print("Enter Amount of Loan: ");
            account.setLoan(Double.parseDouble(s.nextLine()));
            System.out.print("Enter Term(Month/s): ");
            account.setTerm(Integer.parseInt(s.nextLine()));
            account.setInterest(getInterestRating(account) / 100);

        } catch (Exception e) {
            System.out.println("\nMust Fill The Information");
            return;
        }

        try {
            systemAccount.createLoanAccount(account);
        } catch (IOException ignored) {
        }
    }
    private double getInterestRating(LoanAccount account) {
        double rate = 0;
        if (account.getLoan() >= 1 && account.getLoan() <= 100) {
            rate = 100;
        }
        if (account.getLoan() > 100 && account.getLoan() <= 500) {
            rate = 75;
        }
        if (account.getLoan() > 500 && account.getLoan() <= 1000) {
            rate = 50;
        }
        if (account.getLoan() > 1000 && account.getLoan() <= 10000) {
            rate = 18.5;
        }
        if (account.getLoan() > 10000 && account.getLoan() <= 25000) {
            rate = 16.5;
        }
        if (account.getLoan() > 25000 && account.getLoan() <= 50000) {
            rate = 14.5;
        }
        if (account.getLoan() > 50000 && account.getLoan() <= 75000) {
            rate = 12.5;
        }
        if (account.getLoan() > 75000 && account.getLoan() <= 100000) {
            rate = 10.5;
        }
        if (account.getLoan() > 100000 && account.getLoan() <= 250000) {
            rate = 8;
        }
        if (account.getLoan() > 250000 && account.getLoan() <= 500000) {
            rate = 7;
        }
        if (account.getLoan() > 500000 && account.getLoan() <= 750000) {
            rate = 6;
        }
        if (account.getLoan() > 750000 && account.getLoan() <= 1000000) {
            rate = 5;
        }
        if (account.getLoan() > 1000000 && account.getLoan() <= 2500000) {
            rate = 4;
        }
        if (account.getLoan() > 2500000 && account.getLoan() <= 5000000) {
            rate = 3;
        }
        if (account.getLoan() > 5000000 && account.getLoan() <= 10000000) {
            rate = 2.5;
        }

        return rate;
    }

    public void PayLoan() {
        choice = 0;
        System.out.println("\n==================== Pay Loan ===================\n");
        System.out.print("Enter Account ID: ");
        int id = 0;
        try {
            id = Integer.parseInt(s.nextLine());
        } catch (NumberFormatException ignored) {}


        if (systemAccount.isIDExist(id)) {
            LoanAccount loanAccount = systemAccount.retrieveLoanAccount(id);
            if (loanAccount.getTerm() != loanAccount.getTermPayed()) {
                choice = 0;
                System.out.print("[1] Pay Monthly\n[2] Pay Principal\nEnter choice: ");
                try {
                    choice = Integer.parseInt(s.nextLine());
                } catch (NumberFormatException ignored) {}

                if (choice == 1) {
                    System.out.println("\nMonth #" + (loanAccount.getTermPayed()+1));
                    System.out.printf("Balance: %.2f", loanAccount.getLoanThisMonth());
                    if(loanAccount.getTermPayed()+1 != loanAccount.getTerm()){
                        System.out.println("\nYou can Pay Between: " + String.format("%.2f", (loanAccount.getLoanThisMonth()*0.75))
                                + " - "  + String.format("%.2f", loanAccount.getLoanThisMonth())); }

                    System.out.print("\nEnter Payment: ");
                    double pay;
                    try {pay = Double.parseDouble(s.nextLine()); } catch (NumberFormatException ignored) { return; }

                    if (systemAccount.confirmTransaction(loanAccount, pay)){
                        Record record = new Record();
                        record.setId(loanAccount.getId());
                        record.setTerm(loanAccount.getTermPayed()+1);
                        record.setBalance(loanAccount.getLoanThisMonth());
                        record.setPay(pay);
                        try { systemRecord.createRecord(record); } catch (IOException ignored) {}

                        loanAccount.setPrincipalPayed(1);
                        loanAccount.setPay(pay);
                        loanAccount.setTermPayed(loanAccount.getTermPayed()+1);
                        try { systemAccount.updateLoanAccount(loanAccount); } catch (IOException ignored) {}
                    }else{ System.out.println("\nTransaction Request Denied"); }
                }
                else if(choice == 2) {
                    if(loanAccount.getPrincipalPayed()){
                        System.out.println("You can pay your Principal only by 30% each month");
                        System.out.println("Pay between " + String.format("%.2f",  1.00) + " - " +
                                String.format("%.2f", loanAccount.getTotalPrincipal()*0.30));

                        System.out.print("\nEnter Payment: ");
                        double pay;
                        try {pay = Double.parseDouble(s.nextLine()); } catch (NumberFormatException ignored) { return; }

                        if(systemAccount.confirmPrincipal(loanAccount, pay)){
                            loanAccount.setPrincipal(pay);
                            loanAccount.setPrincipalPayed(2);
                            try { systemAccount.updateLoanAccount(loanAccount); } catch (IOException ignored) {}

                            if(loanAccount.getLoanThisMonth() == 0){
                                Record record = new Record();
                                record.setId(loanAccount.getId());
                                record.setTerm(loanAccount.getTermPayed()+1);
                                record.setBalance(loanAccount.getLoanThisMonth());
                                record.setPay(0);
                                try { systemRecord.createRecord(record); } catch (IOException ignored) {}

                                loanAccount.setPrincipalPayed(1);
                                loanAccount.setPay(0);
                                loanAccount.setTermPayed(loanAccount.getTermPayed()+1);
                                try { systemAccount.updateLoanAccount(loanAccount); } catch (IOException ignored) {}
                            }
                        }else{ System.out.println("\nTransaction Request Denied"); }
                    }else{ System.out.println("\nYou can only pay once a month."); }

                }else{ System.out.println("\nInvalid Input"); }

            }else{ System.out.println("\nYou Already Payed Your Loan"); }
        }else{System.out.println("\nAccount Does Not Exist");}}

    public void ShowLoanAccountDetails(){
        System.out.println("\n============ LoanAccount Information ============\n");
        choice = 0;
        System.out.print("Enter Account ID: ");
        int id = 0;
        try { id = Integer.parseInt(s.nextLine()); }catch (NumberFormatException ignored){}

        if(systemAccount.isIDExist(id)){
            LoanAccount loanAccount = systemAccount.retrieveLoanAccount(id);
            System.out.println("=================================================\n");
            //personal
            System.out.println("Account ID:\t\t\t" + loanAccount.getId());
            System.out.println("Name:\t\t\t\t" + loanAccount.getName());
            System.out.println("Address:\t\t\t" + loanAccount.getAddress());
            System.out.println("Number:\t\t\t\t" + loanAccount.getNumber());

            //loan details
            System.out.printf("\nMoney Loaned:\t\t%.2f", loanAccount.getLoan());
            System.out.println("\nTerm(Month/s):\t\t" + loanAccount.getTerm());
            System.out.println("Interest:\t\t\t" + loanAccount.getInterest()*100 + "%");

            //loan details
            System.out.printf("\nTotal Interest:\t\t%.2f", loanAccount.getTotalInterestRate());
            System.out.printf("\nTotal Loaned:\t\t%.2f", loanAccount.getTotalLoaned());
            System.out.printf("\nTotal Payed Loan:\t%.2f", loanAccount.getPay());
            System.out.printf("\nPrincipal Payed:\t%.2f", loanAccount.getPrincipal());
            System.out.println("\nTotal TermPayed:\t" + loanAccount.getTermPayed());
            System.out.printf("Total Payed:\t\t%.2f", (loanAccount.getPay() + loanAccount.getPrincipal()));

            //loan month details
            System.out.println("\n\n_________________________________________________\n");
            System.out.println("\t\t\t\tBalance\t\tPayment\t\tStatus\n");
            for(int i = 0; i < loanAccount.getTerm(); i++){
                Record record = systemRecord.retrieveRecord(loanAccount.getId(), i+1);
                System.out.print("Month #" + (i+1) + ":\t\t");
                if(record != null){
                    if (record.getPay() == record.getBalance()){
                        System.out.println(String.format("%.2f",record.getBalance()) + "\t\t"
                                + String.format("%.2f",record.getPay()) + "\t\tPaid."); }
                    else{
                        System.out.println(String.format("%.2f",record.getBalance()) + "\t\t"
                                + String.format("%.2f",record.getPay()) +
                                "\t\tPaid("+ String.format("%.2f", (record.getPay() - record.getBalance())) +")."); }
                }else{
                    record = systemRecord.retrieveRecord(loanAccount.getId(), i);
                    if(record != null){
                        System.out.println(String.format("%.2f", loanAccount.getLoanThisMonth()) +
                                "\t     ---  \t    --  ");}else{
                        System.out.println(String.format("%.2f", loanAccount.getLoanPerMonth()) +
                                "\t     ---  \t    --  ");}}}
            System.out.println("_________________________________________________\n");
            System.out.println("Remaining Balance:\t\t" + String.format("%.2f", loanAccount.getRemainingBalance()));
        }else{ System.out.println("\nAccount Does Not Exist"); }
    }

}
