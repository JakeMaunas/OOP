import FrontEnd.MainFrame;
public class LendingSystem {
    public static void main(String[] args) {
        new MainFrame();
    }
}
