package ConstantConstraints;

import java.awt.*;
import java.io.File;
import java.io.IOException;

public class ConCons {
    public final static int Grid = 10;

    public static Font Inter_Light(){
        Font Inter_Light = null;
        try {
            Inter_Light = Font.createFont(Font.TRUETYPE_FONT, new File("Resources/Fonts/Inter_18pt-Light.ttf"));
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("Resources/Fonts/Inter_18pt-Light.ttf")));
        }catch (IOException | FontFormatException ignored){}
        return Inter_Light;
    }

    public static Font Inter_MediumItalic(){
        Font Inter_Medium = null;
        try {
            Inter_Medium = Font.createFont(Font.TRUETYPE_FONT, new File("Resources/Fonts/Inter_18pt-MediumItalic.ttf"));
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("Resources/Fonts/Inter_18pt-MediumItalic.ttf")));
        }catch (IOException | FontFormatException ignored){}
        return Inter_Medium;
    }

    public static Font Inter_Regular(){
        Font Inter_Regular = null;
        try {
            Inter_Regular = Font.createFont(Font.TRUETYPE_FONT, new File("Resources/Fonts/Inter_18pt-Regular.ttf"));
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("Resources/Fonts/Inter_18pt-Regular.ttf")));
        }catch (IOException | FontFormatException ignored){}
        return Inter_Regular;
    }
}
