package FrontEnd;

import javax.swing.*;

import BackEnd.LoanAccount;
import BackEnd.SystemLoanAccount;
import ConstantConstraints.ConCons;
import FrontEnd.Components.Label;
import FrontEnd.Components.TextField;
import FrontEnd.Components.Button;

import java.awt.*;
import java.io.IOException;

public class AddLoanPanel extends JPanel {
    public AddLoanPanel(){
        init();
        initComponents();
        setVisible(false);
    }

    private void init(){
        setLayout(null);
        setSize(900, 450);
        setLocation(4*ConCons.Grid, 13*ConCons.Grid);
        setBackground(Color.decode("#201E43"));
        setBorder(BorderFactory.createLineBorder(Color.white,2));
    }

    private void initComponents(){
        ImageIcon icon = new ImageIcon("Resources/Icons/AddLoan.png");
        JLabel addicon = new JLabel(icon);
        addicon.setBounds(30*ConCons.Grid,5,65,65);
        add(addicon);

        Label addloanlabel = new Label("#EEEDEB", "AddLoan Account", 36, 2, 240, 30);
        addloanlabel.setFont(ConCons.Inter_MediumItalic().deriveFont(25f));
        addloanlabel.setHorizontalAlignment(JLabel.CENTER);
        add(addloanlabel);

        TextField idtxt = new TextField(2, "Enter Account ID");
        idtxt.setLocation(5*ConCons.Grid, 11*ConCons.Grid);
        add(idtxt);

        TextField nametxt = new TextField(2, "Enter Full Name");
        nametxt.setLocation(5*ConCons.Grid, 19*ConCons.Grid);
        add(nametxt);

        TextField addresstxt = new TextField(2, "Enter Address");
        addresstxt.setLocation(5*ConCons.Grid, 27*ConCons.Grid);
        add(addresstxt);

        TextField numbertxt = new TextField(2, "Enter Contact Number");
        numbertxt.setLocation(5*ConCons.Grid, 35*ConCons.Grid);
        add(numbertxt);

        TextField ammtxt = new TextField(2, "Enter Ammount Loan");
        ammtxt.setLocation(50*ConCons.Grid, 11*ConCons.Grid);
        add(ammtxt);

        TextField termtxt = new TextField(2, "Enter Term of Loan");
        termtxt.setLocation(50*ConCons.Grid, 19*ConCons.Grid);
        add(termtxt);

        TextField interesttxt = new TextField(2, "Enter Interest");
        interesttxt.setLocation(50*ConCons.Grid, 27*ConCons.Grid);
        add(interesttxt);

        Button addbtn = new Button(1);
        addbtn.setText("Add");
        addbtn.setLocation(61*ConCons.Grid, 35*ConCons.Grid);

        addbtn.addActionListener(e -> {
            boolean f = true;
            int id = 0, term = 0;
            double ammount = 0, rate = 0;
            try{ id = Integer.parseInt(idtxt.getText());
                if(Integer.parseInt(idtxt.getText()) == 0 || idtxt.getText().equals("Enter Account ID")){
                    idtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;
                }}catch (Exception a) {
                idtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;}

            try{ term = Integer.parseInt(termtxt.getText());
                if(Integer.parseInt(termtxt.getText()) == 0 || termtxt.getText().equals("Enter Term of Loan")){
                    termtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;
                }}catch (Exception a) {
                termtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;}

            try{ ammount = Integer.parseInt(ammtxt.getText());
                if(Integer.parseInt(ammtxt.getText()) == 0 || ammtxt.getText().equals("Enter Ammount Loan")){
                    ammtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;
                }}catch (Exception a) {
                ammtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;}

            try{ rate = Integer.parseInt(interesttxt.getText());
                if(Integer.parseInt(interesttxt.getText()) == 0 || interesttxt.getText().equals("Enter Ammount Loan")){
                    interesttxt.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;
                }}catch (Exception a) {
                interesttxt.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;}

            if(!nametxt.getText().contains(" ") || nametxt.getText().equals("Enter Full Name")){
                nametxt.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;}

            if(addresstxt.getText().equals("Enter Address")){
                addresstxt.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;}

            if(numbertxt.getText().equals("Enter Contact Number") || numbertxt.getText().length() != 11){
                numbertxt.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;}

            if(f){
                LoanAccount loanAccount = new LoanAccount();
                loanAccount.setId(id);
                loanAccount.setName(nametxt.getText());
                loanAccount.setAddress(addresstxt.getText());
                loanAccount.setContactNumber(numbertxt.getText());
                loanAccount.setLoan(ammount);
                loanAccount.setTerm(term);
                loanAccount.setRate(rate/100);
                try {
                    new SystemLoanAccount().createLoanAccount(loanAccount); } catch (IOException ex) {
                    throw new RuntimeException(ex); }
                setVisible(false);
                MainFrame.LendingText.setVisible(true);
            }
        });
        add(addbtn);
    }
}
