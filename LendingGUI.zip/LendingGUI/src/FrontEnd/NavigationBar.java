package FrontEnd;

import FrontEnd.Components.Button;

import javax.swing.*;
import java.awt.*;

import ConstantConstraints.ConCons;

public class NavigationBar extends JPanel {
    public NavigationBar(){
        init();
        initComponents();
        setVisible(false);
    }

    private void init(){
        setLayout(null);
        setSize(984,100);
        setLocation(0,0);
        setBackground(Color.decode("#091057"));
        setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
    }

    private void initComponents(){
        Button addloanbtn = new Button(2);
        addloanbtn.setText("AddLoan");
        addloanbtn.setLocation(15*ConCons.Grid,25);

        addloanbtn.addActionListener(e ->{
            MainFrame.RefreshTables();
            MainFrame.addLoanPanel.setVisible(true);
            MainFrame.LendingText.setVisible(false);
        });
        add(addloanbtn);


        Button payloanbtn = new Button(2);
        payloanbtn.setText("PayLoan");
        payloanbtn.setLocation(42*ConCons.Grid,25);

        payloanbtn.addActionListener(e ->{
            MainFrame.RefreshTables();
            MainFrame.payLoanPanel.setVisible(true);
            MainFrame.LendingText.setVisible(false);
        });
        add(payloanbtn);


        Button accountbtn = new Button(2);
        accountbtn.setText("Account");
        accountbtn.setLocation(70*ConCons.Grid,25);

        accountbtn.addActionListener(e ->{
            MainFrame.RefreshTables();
            MainFrame.accountPanel.setVisible(true);
            MainFrame.LendingText.setVisible(false);
        });
        add(accountbtn);
    }
}
