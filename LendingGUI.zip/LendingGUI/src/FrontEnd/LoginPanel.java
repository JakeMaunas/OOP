package FrontEnd;

import javax.swing.*;
import ConstantConstraints.ConCons;
import FrontEnd.Components.Label;
import FrontEnd.Components.TextField;
import FrontEnd.Components.Button;
import Data.AdminData;
import BackEnd.AdminAccount;

import java.awt.*;

public class LoginPanel extends JPanel {

    public LoginPanel(){
        init();
        initComponents();
    }

    private void init(){
        setLayout(null);
        setSize(400, 300);
        setLocation(30*ConCons.Grid, 15*ConCons.Grid);
        setBackground(Color.decode("#201E43"));
        setBorder(BorderFactory.createLineBorder(Color.decode("#3C3D37"), 2));
    }

    private void initComponents(){
        Label login = new Label("#F4F6FF", "Login", 16, 2, 100, 35);
        login.setFont(ConCons.Inter_MediumItalic().deriveFont(30f));
        login.setFocusable(true);
        add(login);

        TextField username = new TextField(1, "Username");
        username.setLocation(73,110);
        add(username);

        TextField password = new TextField(1, "Password");
        password.setLocation(73,150);
        add(password);

        Button loginbtn = new Button(1);
        loginbtn.setText("Login");
        loginbtn.setLocation(13*ConCons.Grid, 22*ConCons.Grid);

        loginbtn.addActionListener(e -> {
            AdminAccount adm = AdminData.getAdminAccount();
            boolean f = true;
            if(username.getText().equals("Username") || !adm.getUsername().equals(username.getText())){
                username.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;
            }

            if(password.getText().equals("Password") || !adm.getPassword().equals(password.getText())){
                password.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;
            }

            if (f){
                setVisible(false);
                repaint();

                MainFrame.navigationBar.setVisible(true);
                MainFrame.LendingText.setVisible(true);
            }
        });
        add(loginbtn);
    }
}
