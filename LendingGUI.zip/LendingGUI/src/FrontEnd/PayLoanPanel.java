package FrontEnd;

import javax.swing.*;

import BackEnd.Record;
import ConstantConstraints.ConCons;
import FrontEnd.Components.Label;
import FrontEnd.Components.TextField;
import FrontEnd.Components.Button;
import FrontEnd.Components.TextArea;
import BackEnd.*;

import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;

public class PayLoanPanel extends JPanel {
    private final SystemLoanAccount systemLoanAccount = new SystemLoanAccount();
    private final SystemRecord systemRecord = new SystemRecord();
    private TextArea textArea;

    public PayLoanPanel(){
        init();
        initComponents();
        setVisible(false);
    }

    private void init(){
        setLayout(null);
        setSize(900,400);
        setLocation(4*ConCons.Grid, 13*ConCons.Grid);
        setBackground(Color.decode("#201E43"));
        setBorder(BorderFactory.createLineBorder(Color.white,2));
    }

    private void initComponents() {
        ImageIcon icon = new ImageIcon("Resources/Icons/PayLoan.png");
        JLabel payicon = new JLabel(icon);
        payicon.setBounds(35 * ConCons.Grid, 5, 65, 65);
        add(payicon);

        FrontEnd.Components.Label addloanlabel = new Label("#EEEDEB", "Pay Loan", 36, 2, 240, 30);
        addloanlabel.setFont(ConCons.Inter_MediumItalic().deriveFont(25f));
        addloanlabel.setHorizontalAlignment(JLabel.CENTER);
        add(addloanlabel);

        TextField idtxt = new TextField(2,"Enter LoanAccount ID");
        idtxt.setLocation(5*ConCons.Grid, 14*ConCons.Grid);

        idtxt.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER){
                    try {
                        if(systemLoanAccount.isIDExist(Integer.parseInt(idtxt.getText()))){
                            if(systemLoanAccount.retrieveLoanAccount(Integer.parseInt(idtxt.getText())).getPay() ==
                                    systemLoanAccount.retrieveLoanAccount(Integer.parseInt(idtxt.getText())).getTotalLoan()){
                                remove(textArea);
                                textArea = new TextArea("\n\n\n\n        Account Loan had Already been payed");
                            }else if (systemLoanAccount.isIDExist(Integer.parseInt(idtxt.getText()))){
                                remove(textArea);
                                textArea = new TextArea(getAccountPayment(systemLoanAccount.retrieveLoanAccount(Integer.parseInt(idtxt.getText()))));}
                        }else{
                            idtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2));
                            remove(textArea);
                            textArea = new TextArea("\n\n\n\n                    Account Does Not Exist");}
                    }catch (NumberFormatException a){idtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2));
                        remove(textArea);
                        textArea = new TextArea("\n\n\n\n                        Invalid Account ID");}
                    textArea.setSize(35*ConCons.Grid,21*ConCons.Grid);
                    textArea.setLocation(50*ConCons.Grid, 11*ConCons.Grid);
                    add(textArea);
                    revalidate();
                    repaint();
                }}
            @Override
            public void keyReleased(KeyEvent e) {}
        });
        idtxt.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {}
            @Override
            public void focusLost(FocusEvent e) {
                try {
                    if(systemLoanAccount.isIDExist(Integer.parseInt(idtxt.getText()))){
                        if(systemLoanAccount.retrieveLoanAccount(Integer.parseInt(idtxt.getText())).getPay() ==
                                systemLoanAccount.retrieveLoanAccount(Integer.parseInt(idtxt.getText())).getTotalLoan()){
                            idtxt.setBorder(BorderFactory.createLineBorder(Color.decode("#3C3D37")));
                            remove(textArea);
                            textArea = new TextArea("\n\n\n\n        Account Loan had Already been payed");
                        }else if (systemLoanAccount.isIDExist(Integer.parseInt(idtxt.getText()))){
                            idtxt.setBorder(BorderFactory.createLineBorder(Color.decode("#3C3D37")));
                            remove(textArea);
                            textArea = new TextArea(getAccountPayment(systemLoanAccount.retrieveLoanAccount(Integer.parseInt(idtxt.getText()))));}
                    }else{
                        idtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2));
                        remove(textArea);
                        textArea = new TextArea("\n\n\n\n                    Account Does Not Exist");}
                }catch (NumberFormatException a){idtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2));
                    idtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2));
                    remove(textArea);
                    textArea = new TextArea("\n\n\n\n                        Invalid Account ID");}
                textArea.setSize(35*ConCons.Grid,21*ConCons.Grid);
                textArea.setLocation(50*ConCons.Grid, 11*ConCons.Grid);
                add(textArea);
                revalidate();
                repaint();}});
        add(idtxt);

        TextField ammtxt = new TextField(2,"Enter Payment");
        ammtxt.setLocation(5*ConCons.Grid, 21*ConCons.Grid);
        add(ammtxt);

        textArea = new TextArea("");
        textArea.setSize(35*ConCons.Grid,21*ConCons.Grid);
        textArea.setLocation(50*ConCons.Grid, 11*ConCons.Grid);
        add(textArea);

        Button paybtn = new Button(1);
        paybtn.setText("Pay Loan");
        paybtn.setLocation(15*ConCons.Grid, 28*ConCons.Grid);
        add(paybtn);

        paybtn.addActionListener(e -> {
            boolean f = true;
            int id = 0;
            double amm = 0;
            try{ amm = Double.parseDouble(ammtxt.getText()); } catch (NumberFormatException a){
                ammtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2)); f = false;}
            try{ id = Integer.parseInt(idtxt.getText()); } catch (NumberFormatException a){
                f = false;}

            if(f){
                LoanAccount loanAccount = systemLoanAccount.retrieveLoanAccount(id);
                Record record = new Record();
                if(systemLoanAccount.confirmTransaction(loanAccount, amm) && loanAccount.getTermPayed() != loanAccount.getTerm()){
                    record.setPay(amm);
                    record.setId(loanAccount.getId());
                    record.setTerm(loanAccount.getTermPayed()+1);
                    record.setBalance(loanAccount.getLoanThisMonth());
                    loanAccount.setPay(amm);
                    loanAccount.setTermPayed(loanAccount.getTermPayed()+1);
                    JOptionPane.showMessageDialog(null, "Transaction Accepted", "Success", JOptionPane.INFORMATION_MESSAGE);
                    try {
                        systemLoanAccount.updateLoanAccount(loanAccount);
                        systemRecord.createRecord(record);
                    } catch (IOException ex) {throw new RuntimeException(ex);}
                    idtxt.setText("Enter LoanAccount ID");
                    ammtxt.setText("Enter Payment");

                    remove(textArea);
                    textArea = new TextArea("");
                    textArea.setSize(35*ConCons.Grid,21*ConCons.Grid);
                    textArea.setLocation(50*ConCons.Grid, 11*ConCons.Grid);
                    add(textArea);
                    revalidate();
                    repaint();
                }else{
                    JOptionPane.showMessageDialog(null, "Transaction Denied", "Warning", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
    }

    private String getAccountPayment(LoanAccount loanAccount){
        String info = "";
        info += "\n\n  Account ID: " + loanAccount.getId() +
                "\n  Account Name: " + loanAccount.getName() +
                "\n\n  Month #" + (loanAccount.getTermPayed()+1) +
                "\n  Balance: " + String.format("%.2f", loanAccount.getLoanThisMonth());
        if(loanAccount.getTermPayed()+1 != loanAccount.getTerm()){
            info += "\n  You can Pay Between: " + String.format("%.2f", (loanAccount.getLoanThisMonth()*0.75))
                    + " - "  + String.format("%.2f", loanAccount.getLoanThisMonth());}

        return info;
    }
}
