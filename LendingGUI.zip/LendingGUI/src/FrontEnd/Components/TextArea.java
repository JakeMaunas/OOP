package FrontEnd.Components;

import javax.swing.*;
import ConstantConstraints.ConCons;

import java.awt.*;

public class TextArea extends JTextArea {

    public JScrollPane scrollPane;

    public TextArea(String text){
        init(text);
        initComponents();
        setVisible(true);
    }

    private void init(String text){
        setText(text);
        setLineWrap(true);
        setWrapStyleWord(true);
        setFont(ConCons.Inter_Regular().deriveFont(16f));
        setEditable(false);
        setFocusable(false);
        setBackground(Color.decode("#C0C8CA"));
        setBorder(BorderFactory.createLineBorder(Color.decode("#1A2D42")));
    }

    private void initComponents(){
        scrollPane = new JScrollPane(this);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
    }
}
