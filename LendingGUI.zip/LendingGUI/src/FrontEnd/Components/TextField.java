package FrontEnd.Components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import ConstantConstraints.ConCons;

public class TextField extends JTextField {

    public TextField(int type, String text){
        setFont(ConCons.Inter_Light().deriveFont(16f));
        setText(text);
        setHorizontalAlignment(JTextField.CENTER);
        setBorder(BorderFactory.createLineBorder(Color.decode("#3C3D37")));
        setForeground(Color.decode("#686D76"));

        if(type == 1){ setSize(250, 30);
        }else{ setSize(350, 30); }

        addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                setBorder(BorderFactory.createLineBorder(Color.decode("#3C3D37")));
                setForeground(Color.black);
                if(getText().equals(text)){
                    setText("");
                }else{
                    setText(getText());
                }
            }
            @Override
            public void focusLost(FocusEvent e) {
                if(getText().isEmpty()){
                    setForeground(Color.decode("#686D76"));
                    setText(text);
                }
            }
        });
    }
}
