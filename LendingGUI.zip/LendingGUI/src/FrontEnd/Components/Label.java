package FrontEnd.Components;

import ConstantConstraints.ConCons;

import javax.swing.*;
import java.awt.*;

public class Label extends JLabel {

    public Label(String color, String title, int x, int y, int w, int h){
        setText(title);
        setBounds(x* ConCons.Grid,y*ConCons.Grid, w, h);
        setForeground(Color.decode(color));
        setFocusable(false);
    }
}
