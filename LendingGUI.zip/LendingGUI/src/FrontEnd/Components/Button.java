package FrontEnd.Components;

import javax.swing.*;
import ConstantConstraints.ConCons;

import java.awt.*;

public class Button extends JButton {
    public Button(int type){
        setFocusable(false);
        setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        if(type == 1){
            setBackground(Color.decode("#024CAA"));
            setForeground(Color.decode("#F4F6FF"));
            setSize(130,40);
            setFont(ConCons.Inter_Regular().deriveFont(20f));
        }else{
            setBackground(Color.decode("#B7B7B7"));
            setForeground(Color.decode("#181C14"));
            setSize(150,45);
            setFont(ConCons.Inter_Regular().deriveFont(18f));
        }
    }
}
