package FrontEnd;

import BackEnd.LoanAccount;
import BackEnd.Record;
import BackEnd.SystemLoanAccount;
import BackEnd.SystemRecord;
import ConstantConstraints.ConCons;
import FrontEnd.Components.Label;
import FrontEnd.Components.TextArea;
import FrontEnd.Components.TextField;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class AccountPanel extends JPanel {
    private final SystemLoanAccount systemLoanAccount = new SystemLoanAccount();
    private final SystemRecord systemRecord = new SystemRecord();
    private TextArea textArea;

    public AccountPanel(){
        init();
        initComponents();
        setVisible(false);
    }

    private void init(){
        setLayout(null);
        setSize(900,400);
        setLocation(4* ConCons.Grid, 13*ConCons.Grid);
        setBackground(Color.decode("#201E43"));
        setBorder(BorderFactory.createLineBorder(Color.white,2));
    }

    private void initComponents() {
        ImageIcon icon = new ImageIcon("Resources/Icons/Account.png");
        JLabel payicon = new JLabel(icon);
        payicon.setBounds(32 * ConCons.Grid, 5, 65, 65);
        add(payicon);

        FrontEnd.Components.Label addloanlabel = new Label("#EEEDEB", "Loan Account", 37, 2, 240, 30);
        addloanlabel.setFont(ConCons.Inter_MediumItalic().deriveFont(25f));
        addloanlabel.setHorizontalAlignment(JLabel.CENTER);
        add(addloanlabel);

        TextField idtxt = new TextField(2,"Enter LoanAccount ID");
        idtxt.setLocation(27*ConCons.Grid, 8*ConCons.Grid);
        idtxt.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER){
                    try{
                        if(!idtxt.getText().equals("Enter LoanAccount ID")){
                            if (systemLoanAccount.isIDExist(Integer.parseInt(idtxt.getText()))){
                                remove(textArea.scrollPane);
                                textArea = new TextArea(getAccountInfo(Integer.parseInt(idtxt.getText())));
                                textArea.scrollPane.setSize(60 * ConCons.Grid, 25 * ConCons.Grid);
                                textArea.scrollPane.setLocation(15 * ConCons.Grid, 12 * ConCons.Grid);
                                add(textArea.scrollPane);
                                idtxt.setFocusable(false);
                                idtxt.setText("Enter LoanAccount ID");
                                idtxt.setForeground(Color.decode("#686D76"));
                                revalidate();
                                repaint();
                                idtxt.setFocusable(true);
                            }else{idtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2));}}
                    }catch (NumberFormatException a){
                        idtxt.setBorder(BorderFactory.createLineBorder(Color.red, 2));
                    }
                }
            }
            @Override
            public void keyReleased(KeyEvent e) {}
        });
        add(idtxt);

        textArea = new TextArea("");
        textArea.scrollPane.setSize(60*ConCons.Grid,25*ConCons.Grid);
        textArea.scrollPane.setLocation(15*ConCons.Grid, 12*ConCons.Grid);
        add(textArea.scrollPane);
    }

    private String getAccountInfo(int id){
        StringBuilder info = new StringBuilder();

        LoanAccount loanAccount = systemLoanAccount.retrieveLoanAccount(id);

        info.append("=========================================================\n");

        //personal
        info.append("\n Account ID:\t\t").append(loanAccount.getId());
        info.append("\n Name:\t\t").append(loanAccount.getName());
        info.append("\n Address:\t\t").append(loanAccount.getAddress());
        info.append("\n Number:\t\t").append(loanAccount.getContactNumber());

        //loan details
        info.append("\n\n Money Loaned:\t").append(String.format("%.2f", loanAccount.getLoan()));
        info.append("\n Term(Month/s):\t").append(loanAccount.getTerm());
        info.append("\n Rate(Interest):\t\t").append(loanAccount.getRate() * 100).append("%");

        //loan details
        info.append("\n\n Total Loaned:\t\t").append(String.format("%.2f", loanAccount.getTotalLoan()));
        info.append("\n Total TermPayed:\t").append(loanAccount.getTermPayed());
        info.append("\n Total Payed:\t\t").append(String.format("%.2f", loanAccount.getPay()));

        //loan month details
        info.append("\n__________________________________________________________________________________\n\n");
        info.append("\t Balance\tPayment\tStatus\n");
        for(int i = 0; i < loanAccount.getTerm(); i++){
            Record record = systemRecord.retrieveRecord(loanAccount.getId(), i+1);
            info.append("\n Month #").append(i + 1).append(":\t");
            if(record != null){
                if (record.getPay() == record.getBalance()){
                    info.append(String.format("%.2f", record.getBalance())).append("\t").append(String.format("%.2f", record.getPay())).append("\tPaid."); }
                else{
                    info.append(String.format("%.2f", record.getBalance())).append("\t").append(String.format("%.2f", record.getPay())).append("\tPaid(").append(String.format("%.2f", (record.getPay() - record.getBalance()))).append(")."); }
            }else{
                record = systemRecord.retrieveRecord(loanAccount.getId(), i);
                if(record != null){
                    info.append(String.format("%.2f", loanAccount.getLoanThisMonth())).append("\t     ---  \t    --  ");}else{
                    info.append(String.format("%.2f", loanAccount.getLoanPerMonth())).append("\t     ---  \t    --  ");}}}
        info.append("\n__________________________________________________________________________________\n");
        info.append(" Remaining Balance:\t").append(String.format("%.2f", loanAccount.getRemainingBalance()));

        info.append("\n=========================================================");
        return info.toString();
    }
}
