package FrontEnd;

import javax.swing.*;
import java.awt.*;
import ConstantConstraints.ConCons;
import FrontEnd.Components.Label;

public class MainFrame{

    public static LoginPanel loginPanel;
    public static NavigationBar navigationBar;
    public static Label LendingText;
    public static AddLoanPanel addLoanPanel;
    public static PayLoanPanel payLoanPanel;
    public static AccountPanel accountPanel;
    public static JFrame frame = new JFrame();

    public MainFrame(){
        init();
        initComponents();
        frame.setVisible(true);
    }

    private void init(){
        frame.setLayout(null);
        frame.setSize(1000, 650);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(Color.decode("#1E201E"));
    }

    private void initComponents(){
        LendingText = new Label("#EEEDEB", "Lending System", 30, 20, 400,60);
        LendingText.setFont(ConCons.Inter_MediumItalic().deriveFont(40f));
        LendingText.setHorizontalAlignment(JLabel.CENTER);
        LendingText.setVisible(false);
        frame.add(LendingText);

        loginPanel = new LoginPanel();
        frame.add(loginPanel);

        navigationBar = new NavigationBar();
        frame.add(navigationBar);

        addLoanPanel = new AddLoanPanel();
        frame.add(addLoanPanel);

        payLoanPanel = new PayLoanPanel();
        frame.add(payLoanPanel);

        frame.setIconImage(new ImageIcon("Resources/Icons/Logo.png").getImage());

        accountPanel = new AccountPanel();
    }

    public static void RefreshTables(){
        frame.remove(addLoanPanel);
        frame.remove(payLoanPanel);
        frame.remove(accountPanel);
        addLoanPanel = new AddLoanPanel();
        payLoanPanel = new PayLoanPanel();
        accountPanel = new AccountPanel();
        frame.add(accountPanel);
        frame.add(addLoanPanel);
        frame.add(payLoanPanel);
        frame.revalidate();
        frame.repaint();
    }
}
