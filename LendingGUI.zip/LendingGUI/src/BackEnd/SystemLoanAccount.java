package BackEnd;

import Data.LoanAccountData;

import javax.swing.*;
import java.io.*;
import java.util.*;

public class SystemLoanAccount {

    public void createLoanAccount(LoanAccount account) throws IOException{
        boolean flag = true;
        List<LoanAccount> loanAccountList = LoanAccountData.getLoanAccounts();
        for (LoanAccount accountloan : loanAccountList) {
            if (accountloan .getId() == account.getId()) {
                JOptionPane.showMessageDialog(null, "ID is already taken", "Warning", JOptionPane.WARNING_MESSAGE);
                flag = false; }}

        if (flag) {
            JOptionPane.showMessageDialog(null, "Account successfully Added!", "Success", JOptionPane.INFORMATION_MESSAGE);
            FileWriter fw;
            BufferedWriter bw;
            fw = new FileWriter(LoanAccountData.getFile(), true);
            bw = new BufferedWriter(fw);

            bw.write(account.WriteToFile());
            bw.write("\n");
            bw.close(); }
    }

    public LoanAccount retrieveLoanAccount(int id){
        List<LoanAccount> loanAccountsList = LoanAccountData.getLoanAccounts();
        for(LoanAccount accountloan : loanAccountsList){
            if (accountloan.getId() == id){ return accountloan; }}
        return null;
    }

    public void updateLoanAccount(LoanAccount account) throws IOException{
        List<LoanAccount> loanAccountList = LoanAccountData.getLoanAccounts();

        for(LoanAccount accountloan : loanAccountList){
            if(accountloan.getId() == account.getId()){
                loanAccountList.set(loanAccountList.indexOf(accountloan), account); }}

        StringBuilder format = new StringBuilder();
        for (LoanAccount accountloan : loanAccountList) {
            format.append(accountloan.WriteToFile()).append("\n"); }

        Formatter formatFile = new Formatter(LoanAccountData.getFile());
        formatFile.format("%S", format);
        formatFile.close();
    }

    public boolean isIDExist(int id) {
        List<LoanAccount> loanAccountsList = LoanAccountData.getLoanAccounts();
        for (LoanAccount accountloan : loanAccountsList) {
            if (accountloan.getId() == id){return true;}}
        return false;
    }

    public boolean confirmTransaction(LoanAccount loanAccount, double pay) {
        if (loanAccount.getTerm() == loanAccount.getTermPayed() + 1) {
            return pay == loanAccount.getLoanThisMonth();
        }
        return pay >= Double.parseDouble(String.format("%.2f", loanAccount.getLoanThisMonth())) * 0.75 &&
                pay <= loanAccount.getLoanThisMonth();
    }
}
