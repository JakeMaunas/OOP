package LendingSystem;
public class Main {
    public static void main(String[] args) {
        UserInput input = new UserInput();
    }
}