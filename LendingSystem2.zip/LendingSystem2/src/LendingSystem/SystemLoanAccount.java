package LendingSystem;

import Data.LoanAccountData;
import java.io.*;
import java.util.*;

public class SystemLoanAccount {

    public void createLoanAccount(LoanAccount account) throws IOException{
        boolean flag = true;
        List<LoanAccount> loanAccountList = LoanAccountData.getLoanAccounts();
        for (LoanAccount accountloan : loanAccountList) {
            if (accountloan .getId() == account.getId()) {
                System.out.println("\nDuplicate ID Error");
                flag = false; }}

        if (flag) {
            FileWriter fw;
            BufferedWriter bw;
            fw = new FileWriter(LoanAccountData.getFile(), true);
            bw = new BufferedWriter(fw);

            bw.write(account.WriteToFile());
            bw.write("\n");
            bw.close(); }
    }

    public LoanAccount retrieveLoanAccount(int id){
        List<LoanAccount> loanAccountsList = LoanAccountData.getLoanAccounts();
        for(LoanAccount accountloan : loanAccountsList){
            if (accountloan.getId() == id){ return accountloan; }}
        return null;
    }

    public void updateLoanAccount(LoanAccount account) throws IOException{
        List<LoanAccount> loanAccountList = LoanAccountData.getLoanAccounts();

        for(LoanAccount accountloan : loanAccountList){
            if(accountloan.getId() == account.getId()){
                loanAccountList.set(loanAccountList.indexOf(accountloan), account); }}

        StringBuilder format = new StringBuilder();
        for (LoanAccount accountloan : loanAccountList) {
            format.append(accountloan.WriteToFile()).append("\n"); }

        Formatter formatFile = new Formatter(LoanAccountData.getFile());
        formatFile.format("%S", format);
        formatFile.close();
    }

    public boolean isIDExist(int id) {
        List<LoanAccount> loanAccountsList = LoanAccountData.getLoanAccounts();
        for (LoanAccount accountloan : loanAccountsList) {
            if (accountloan.getId() == id){return true;}}
        return false;
    }

    public boolean confirmTransaction(LoanAccount loanAccount, double pay) {
        if (loanAccount.getTerm() == loanAccount.getTermPayed() + 1) {
            return pay == Double.parseDouble(String.format("%.2f", loanAccount.getLoanThisMonth()));
        }
        return pay >= Double.parseDouble(String.format("%.2f", loanAccount.getLoanThisMonth())) * 0.75 &&
                pay <= Double.parseDouble(String.format("%.2f", loanAccount.getLoanThisMonth()));
    }
}
