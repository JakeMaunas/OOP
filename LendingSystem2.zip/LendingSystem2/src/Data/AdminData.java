package Data;

import java.io.*;
import java.util.Scanner;
import LendingSystem.AdminAccount;

public class AdminData {
    private static final File Admin = new File("Files/AdminAccount.txt");

    public static AdminAccount getAdminAccount(){
        AdminAccount adminAccount = new AdminAccount();
        try {
            Scanner scan = new Scanner(new FileReader(Admin));
            try {
                adminAccount.setUsername(scan.next());
                scan.skip(" - ");
                adminAccount.setPassword(scan.next());
            }catch (Exception ignored) {}
            scan.close();
        }catch (IOException ignored){}
        return adminAccount;
    }
}
